name 'base'
description 'All Instances'
run_list( 
  "recipe[solo-ntpd::default]",
  "recipe[apt]"
)
