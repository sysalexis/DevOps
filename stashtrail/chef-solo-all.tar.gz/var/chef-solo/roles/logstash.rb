name 'logstash'
description 'Logstash'
run_list "recipe[logstash::default]"
