maintainer       "Kobi Biton"
maintainer_email "kobibito@amazon.lu"
license          "All rights reserved"
description      "Installs/Configures logstash"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
