##
# Cookbook Name:: logstash
# Recipe:: default
#
###
include_recipe "apt"

 Chef::Log.info("#################################INSTALLING LOGSTASH###################################")

apt_repository 'logstash' do
  uri          'http://packages.elasticsearch.org/logstash/1.4/debian'
  distribution 'stable'
  components   ['main']
  key          'http://packages.elasticsearch.org/GPG-KEY-elasticsearch'
end

apt_repository 'elasticsearch' do
  uri          'http://packages.elasticsearch.org/elasticsearch/1.1/debian'
  distribution 'stable'
  components   ['main']
  key          'http://packages.elasticsearch.org/GPG-KEY-elasticsearch'
end

apt_package "elasticsearch" do
  action :install
  version "1.1.1"
end

apt_package "logstash" do
  action :install
  version "1.4.1-1-bd507eb"
end

apt_package "logstash-contrib" do
  action :install
  version "1.4.1-1-6e42745"
end

#Service decleration
service "logstash" do
  supports :status => true, :restart => true, :reload => true
  action :enable
end


#Service decleration
service "logstash-web" do
  supports :status => true, :restart => true, :reload => true
  action [ :disable, :stop ]
end

#Service decleration
service "elasticsearch" do
  supports :status => true, :restart => true, :reload => true
  action [ :enable, :start ]
end
  

template "#{node[:logstash][:confdir]}/trail.conf" do
  source "logstash-trail.erb"
  mode 0644
  owner "logstash"
  group "logstash"
  notifies :restart, "service[logstash]", :immediately
end

#Kibana
remote_file "#{node[:kibana][:home]}/kibana-latest.tar.gz" do
   source "http://download.elasticsearch.org/kibana/kibana/kibana-latest.tar.gz"
   mode "0755"
   checksum "9c639e8af3"
   ignore_failure true
 end
 
 bash "ExtractKibana" do
   code <<-EOH
    cd "#{node[:kibana][:home]}"
    /bin/tar xfz "#{node[:kibana][:home]}/kibana-latest.tar.gz"
   EOH
   not_if {File.exists?("#{node[:kibana][:home]}/config.js")}
   notifies :restart, "service[apache2]", :immediately
  end
