Description
===========
Analyze AWS Cloudtrail logs with Logstash, Store them in elasticsearch and search with Kibana

Requirements
============
Ubuntu >=12.04

Attributes
==========

See attributes/default.rb

Usage
=====
Log Analyzing
