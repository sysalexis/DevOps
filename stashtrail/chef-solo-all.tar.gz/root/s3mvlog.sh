#!/bin/bash
source /root/.bootstrap.cfg
tb=`/bin/cat /home/ubuntu/.trailbucket`
aggrprefix=`/bin/cat /home/ubuntu/.aggrprefix`
tpx=`/bin/cat /home/ubuntu/.trailbucketprefix`
/usr/bin/aws s3 mv s3://${tpx}/${REGION}/`date +%Y`/`date +%m`/`date +%d`/ s3://$tb/$aggrprefix --recursive --region us-east-1 2> "/tmp/s3logmv-err.log"
exit 0
